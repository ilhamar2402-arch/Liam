const { default: makeWASocket, useSingleFileAuthState, DisconnectReason } = require('@adiwajshing/baileys')
const { state, saveState } = useSingleFileAuthState('./session.json')
const P = require('pino')

async function startBot() {
  const sock = makeWASocket({
    logger: P({ level: 'silent' }),
    printQRInTerminal: true,
    auth: state
  })

  sock.ev.on('creds.update', saveState)

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    const msg = messages[0]
    if (!msg.message) return

    const from = msg.key.remoteJid
    const body = msg.message.conversation || msg.message.extendedTextMessage?.text || ''

    // Auto-reply salam
    if (body.toLowerCase().includes('assalamualaikum')) {
      await sock.sendMessage(from, { text: 'Waalaikumussalam 👋' }, { quoted: msg })
    }

    // Motivasi random
    else if (body === '.motivasi') {
      const motivasi = [
        'Tetap semangat, jangan menyerah!',
        'Hari ini adalah kesempatan baru 😊',
        'Kegagalan adalah awal dari keberhasilan',
        'Percaya diri, kamu pasti bisa!'
      ]
      const randomMotivasi = motivasi[Math.floor(Math.random() * motivasi.length)]
      await sock.sendMessage(from, { text: randomMotivasi }, { quoted: msg })
    }

    // Waktu sekarang
    else if (body === '.time') {
      const now = new Date()
      await sock.sendMessage(from, { text: `⏰ Sekarang jam: ${now.toLocaleTimeString()} WIB` }, { quoted: msg })
    }

    // Menu utama
    else if (body === '.menu') {
      const menuText = `
╭──❍「 *USER INFO* 」❍
├ *Nama* : Liam
├ *Id* : @liam
├ *User* : FREE
├ *Limit* : 13
├ *Money* : 10.000
╰─┬────❍
╭─┴─❍「 *BOT INFO* 」❍
├ *Nama Bot* : Naki
├ *Powered* : @WhatsApp
├ *Owner* : +625122592544
├ *Mode* : Public
├ *Prefix* : *.*
├ *Premium Feature* : 🔸️
╰─┬────❍
╭─┴─❍「 *ABOUT* 」❍
├ *Tanggal* : ${new Date().toLocaleDateString('id-ID')}
├ *Hari* : ${new Date().toLocaleDateString('id-ID', { weekday: 'long' })}
├ *Jam* : ${new Date().toLocaleTimeString('id-ID')} WIB
╰──────❍

╭──❍「 *BOT* 」❍
│△ .profile
│△ .claim
│△ .buy [item] (nominal)
│△ .transfer
│△ .leaderboard
│△ .request (text)
│△ .react (emoji)
│△ .tagme
│△ .runtime
│△ .totalfitur
│△ .speed
│△ .ping
│△ .afk
│△ .rvo (reply pesan viewone)
│△ .inspect (url gc)
│△ .addmsg
│△ .delmsg
│△ .getmsg
│△ .listmsg
│△ .setcmd
│△ .delcmd
│△ .listcmd
│△ .lockcmd
│△ .q (reply pesan)
│△ .menfes (62xxx|fake name)
│△ .confes (62xxx|fake name)
│△ .roomai
│△ .jadibot 🔸️
│△ .stopjadibot
│△ .listjadibot
│△ .donasi
│△ .addsewa
│△ .delsewa
│△ .listsewa
╰─┬────❍

... (lanjut sesuai menu lengkap)
      `
      await sock.sendMessage(from, { text: menuText }, { quoted: msg })
    }

    // Auto reply mention di grup
    else if (msg.key.participant && body.includes('@')) {
      await sock.sendMessage(from, { text: '👋 Hai, ada yang mention saya?' }, { quoted: msg })
    }
  })
}

startBot()
